package main;

import java.util.Timer;
import java.util.TimerTask;

public class ballkolision {

	Timer kolision;
	public ballkolision() {
		kolision = new Timer();
		kolision.scheduleAtFixedRate(new TimerTask() {

			@Override
			public void run() {

				
				
//				
				if(Gamepanel.ballY   == 420) {
					Gamepanel.balldirY = -1;
			}
				else if(Gamepanel.ballY ==0) {
					Gamepanel.balldirY = 1;
				}
				
				else if(Gamepanel.ballX  == 770) {
					Gamepanel.balldirX= -1;
				}
				
				else if(Gamepanel.ballX  ==0) {
					Gamepanel.balldirX= 1;
					
				}
				//tor & Reset
				 if(Gamepanel.ballX ==0 && Gamepanel.ballY >75 && Gamepanel.ballY < 320   ) {
				Gamepanel.Spielstand2++;
				Gamepanel.playerX = 80;
				Gamepanel.playerY = 210;
				  

					
					
					
					//Spieler 2 standart position
				 Gamepanel.player2X = 650;
				 Gamepanel.player2Y = 210;
				 
				 Gamepanel.ballX = 387;
				 Gamepanel.ballY=210;
				 Gamepanel.balldirY=-1;

				 Gamepanel.balldirX=0;
					
				}
				 
				 else if(Gamepanel.ballX ==750 && Gamepanel.ballY >75 && Gamepanel.ballY < 320   ) {
			     Gamepanel.Spielstand1++;
			     Gamepanel.playerX = 80;
				 Gamepanel.playerY = 210;
						  

						
						
						
						//Spieler 2 standart position
				 Gamepanel.player2X = 650;
				 Gamepanel.player2Y = 210;
						 
						 
				 Gamepanel.ballX = 387;
				 Gamepanel.ballY=210;
						 
				 Gamepanel.balldirY=-1;
				 Gamepanel.balldirX=0;
				
					}
				 
				//_____________________________________
				
				
				
				
//				
//				
//				
			}
			
		},0,8);
		// TODO Auto-generated constructor stub
		
	}
	

	}

