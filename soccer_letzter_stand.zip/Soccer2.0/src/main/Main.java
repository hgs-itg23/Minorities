package main;



import java.awt.Dimension;
import java.awt.event.ActionEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

   

public class Main    {
	JButton hallo1;
//	public boolean hallo1;
	static KeyHandler keyH = new KeyHandler();
	
	public static void main (String[]args) {
		JFrame Spielfeld = new JFrame();
		Spielfeld.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Spielfeld.setResizable(false);
		Spielfeld.setTitle("Soccer by Minoritys");
		Spielfeld.setLocation(360,200);
		Spielfeld.setVisible(true);
		
		
	
		
		Gamepanel gamepanel = new Gamepanel(keyH);
		Spielfeld.add(gamepanel);
		Spielfeld.pack();
		Spielfeld.addKeyListener(keyH);
		gamepanel.startGameThread();
		new Ballmovement();
		new ballkolision();
		
//		
		
		
	}

}
