package main;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Stroke;
import java.awt.Toolkit;
import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;

public class Gamepanel extends JPanel implements Runnable{

	//Einstellungen
	   final static int originalTilesize = 16;
	   final static int scale = 3;
	   final static int tileSize = originalTilesize * scale;
	   final static int maxScreenCol = 16;
	   final static int maxScreenRow = 12;
	   final static int Screenwidth = tileSize * maxScreenCol;
	   static int ScreenHeight = tileSize * maxScreenRow;
       int FPS = 60;
			
	   KeyHandler keyH;
	
	   Thread gameThread;
	
	//Spielers standart position
	   public static int playerX = 80;
	   public static int playerY = 210;
	   public int playerSpeed = 2;
	
	
	
	//Spieler 2 standart position
	   static int player2X = 650;
	   static int player2Y = 210;
	   int player2Speed = 2;
	
	   static int Spielstand1 =0;
	   public static int Spielstand2 =0;
	
	   public boolean kolision() {
		   
	   float absX = (ballX+15) - (playerX+24);
	   float absY = (ballY+15) - (playerY+24);
       float abs = (absX * absX) + (absY * absY);
       if(abs <= ((24*24)+(30*30))) return true;
       
       float absX2 = (ballX+15 ) - (player2X+15);
	   float absY2 = (ballY+15) - (player2Y+15);
       float abs2 = (absX2 * absX2) + (absY2 * absY2);
       if(abs2 <= ((14*14)+(30*30))) return true;
	   return false;
	   }
	   
	    int min = 1;
		int max = 5;

		Random random = new Random();

		int value = random.nextInt(max + min) + min;
    
		
			  
		    
	
		
		
	    public  Gamepanel(KeyHandler keyH) {

		
		
		this.setPreferredSize(new Dimension(800,450));
	
		this.setBackground(new Color(53,190,45));
		this.setDoubleBuffered(true);
	
		//this.addKeyListener(keyH);
		this.keyH = keyH;
		this.setFocusable(true);
		
		
		
		
			}

		public void startGameThread() {
		gameThread = new Thread(this);
		gameThread.start();
	
		}
		public void run() {
		
		double drawIntervall = 1000000000/FPS;
		double delta = 0;
		long lastTime = System.nanoTime();
		long currentTime;
		
		
		while(gameThread != null) {
			
		currentTime = System.nanoTime();
		delta += (currentTime - lastTime) / drawIntervall;
		
		lastTime = currentTime;
		if(delta >= 1) {
		update();
		update2();
		kolision();
//		tor();
//		reset();
		repaint();
		delta--;
			
		}
		
		
			
		//	System.out.println("jldafhv");
			
			
		}
		
	}
	//Spieler 1 _____________________________________________________

	public void update () {
		
		if(keyH.ESC==true) {
			System.exit(0);
		}
		
	boolean kolision = kolision();
		
			
		
		
		
		
		 
	if (kolision==true && playerX<ballX && playerY < ballY) {
		balldirY=1;
		balldirX=1;
	}
	else if(kolision==true && playerX < ballX && playerY > ballY) {
		balldirY=-1;
		balldirX= 1;
	}
		
	
	else if(kolision==true && playerX > ballX && playerY < ballY) {
		balldirY=1;
		balldirX=1;
	}
	else if(kolision==true && playerX > ballX && playerY < ballY) {
		balldirY=-1;
		balldirX=1;
	}
		//player 2
    if (kolision==true && player2X>ballX && player2Y > ballY) {
		balldirY=-1;
		balldirX=-1;
	}
	else if(kolision==true && player2X < ballX && player2Y < ballY) {
		balldirY=1;
		balldirX=-1;
	}
	
	
	
	else if(kolision==true && player2X > ballX && player2Y < ballY) {
		balldirY=1;
		balldirX=-1;
	}
	 
	else if(kolision==true && player2X < ballX && player2Y > ballY) {
		balldirY=-1;
		balldirX=-1;
	}
		//_________________________________
 
	if(keyH.WPressed==true) {
	
		//playerY -= playerSpeed;
		playerY = playerY - playerSpeed;
	}
	else if(keyH.APressed== true) {
		playerX -= playerSpeed;
	}
	else if(keyH.DPressed==true)  {
		playerX += playerSpeed;


	}
	else if(keyH.SPressed==true)  {
		playerY+=playerSpeed;
		
	}
	
	 if (playerY<0) {
		playerY=0;
	}
	 if (playerY>400) {
		playerY=400;
	}
	 if (playerX>750) {
		playerX=750;
	}
	 if (playerX  <0) {
		playerX=0;
	
	
		
	}
	 
	 
	}
	
	
	
	
	
	
	
			 
		
		
	
	
	
	
	
	
	
	//Spieler 2 _____________________________________________________

	public void update2() {
		
		
		
	if(keyH.upPressed==true)         {
		player2Y = player2Y - player2Speed;
	}
	else if(keyH.downPressed== true)  {
		player2Y+=player2Speed;
	}
	else if(keyH.leftPressed==true)   {
		player2X -= player2Speed;

	}
	else if(keyH.rightPressed== true) {
	    player2X += player2Speed;

    }
	
	if (player2Y<0)   {
		player2Y=0;
	}
	if (player2Y>400) {
		player2Y=400;
	}
	if (player2X>750) {
		player2X=750;
	}
	if (player2X  <0) {
		player2X=0;
	}
		//System.out.println("Y="+playerY+"X="+playerX);
	}
	
	
//	public void tor () {
//		
//		if (ballY < 70  && ballY >320 && ballY ==0 ) {
//			Gamepanel.Spielstand2++;
//		}
		
//	}
	
	 static int ballX = 387, ballY=210;
	 static int balldirX =0;
	 static int balldirY =-1;

	 
//	 public boolean tor() {
//		 if(Gamepanel.ballX ==0 && Gamepanel.ballY >75 && Gamepanel.ballY < 320)return true ; 
//     
//			
//		  if(Gamepanel.ballX ==750 && Gamepanel.ballY >75 && Gamepanel.ballY < 320)    return true;
//				
//				
//				
//	  return false;
//	 }
//	 
//	  public void reset () {
//		  boolean tor = tor();
//	  if(tor==true) {
//		  playerX = 80;
//		  playerY = 210;
		  

		
		
		
//		//Spieler 2 standart position
//		 player2X = 650;
//		 player2Y = 210;
//		 
//		 ballX = 387;
//		 ballY=210;
//		 
//		 balldirY=-1;
//		 balldirX=0;
//		 
//    
//		 }
//	  }

	  public void paintComponent(Graphics g) {
		
	  super.paintComponent(g);
		 
	  Graphics2D g2 = (Graphics2D)g;
	  g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
	    
	  Toolkit.getDefaultToolkit().sync();
	 
		 

	  g2.setColor(Color.white);
	  g2.fillRect(400, 0, 3, 900);
	  g2.setColor(Color.white);
	  float thickness = 3;
	  Stroke oldStroke = g2.getStroke();
	  g2.setStroke(new BasicStroke(thickness));
	  g2.drawOval(325, 150, 150, 150);
	  g2.setStroke(oldStroke);
	  
	  
	  g2.setStroke(new BasicStroke(thickness));
	  g2.drawRect(-50, 93, 100, 250);
	  g2.setStroke(oldStroke);
	  
	  
	  g2.setColor(Color.BLUE);
	  g2.fillOval(playerX, playerY, tileSize, tileSize);
	   
	    
	   
	    
	  g2.setColor(Color.white);
	  g2.setStroke(new BasicStroke(thickness));
	  g2.drawRect(747, 93, 100, 250);
	  g2.setStroke(oldStroke);
	 
	  
      g2.setColor(Color.black);
	  g2.fillOval(ballX, ballY, 30,30);
	  
	  
	  g2.setColor(Color.RED);
      g2.fillOval(player2X, player2Y, tileSize, tileSize);
      g2.setColor(Color.BLACK);
	    
	    
	  g.setFont(new Font("Roboto Mono", Font.PLAIN, 50)); 
	  g2.drawString(Spielstand1+" "+":"+" "+Spielstand2 ,346, 60);
	  g2.dispose();
 
	    
	  }
	 
	
	 
	
	
}

