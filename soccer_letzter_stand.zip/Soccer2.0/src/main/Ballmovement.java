package main;
import java.util.Timer;
import java.util.TimerTask;

public class Ballmovement {
	
	
	
	Timer move;	
	
	public  Ballmovement() {
		
	move = new Timer();
	move.scheduleAtFixedRate(new TimerTask() {

		@Override
		public void run() {
			// TODO Auto-generated method stub
			Gamepanel.ballX+=Gamepanel.balldirX;
        	Gamepanel.ballY+=Gamepanel.balldirY;
		}
		
		
			
			
		},3,8);
	}
}


