package main;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class KeyHandler implements KeyListener {

	public boolean upPressed, downPressed, leftPressed, rightPressed,
	  SPressed, APressed, DPressed,WPressed,ESC;
	
	

	public void keyTyped(KeyEvent e) {
		
		
	}

	public void keyPressed(KeyEvent e) {
		
		int code = e.getKeyCode();
		//Spieler 1 _____________________________________________________

		if (code == KeyEvent.VK_W)     {
			WPressed = true;
		}
		if (code == KeyEvent.VK_A)     {
			APressed = true;
			}
		if (code == KeyEvent.VK_D)     {
			DPressed = true;
			}
		if (code == KeyEvent.VK_S)     {
			SPressed = true;
		}
		if(code== KeyEvent.VK_ESCAPE) {
			ESC= true;
	    }
		
		//spieler 2 ______________________________________
		if (code == KeyEvent.VK_UP)    {
			upPressed = true;
		}
		if (code == KeyEvent.VK_LEFT)  {
			leftPressed = true;
			}
		if (code == KeyEvent.VK_RIGHT) {
			rightPressed = true;
			}
		if (code == KeyEvent.VK_DOWN)  {
			downPressed = true;
		}
		
		
	    }

	public void keyReleased(KeyEvent e) {
		int code = e.getKeyCode();
		//Spieler 1 _____________________________________________________

		
		
		if (code == KeyEvent.VK_W)     {
			WPressed = false;
		}
		if (code == KeyEvent.VK_A)     {
			APressed = false;
			}
		if (code == KeyEvent.VK_D)     {
			DPressed = false;
			}
		if (code == KeyEvent.VK_S)     {
			SPressed = false;
			
			//Spieler 2 _____________________________________________________

			}
		if (code == KeyEvent.VK_UP)    {
			upPressed = false;
		}
		if (code == KeyEvent.VK_LEFT)  {
			leftPressed = false;
		}
		if (code == KeyEvent.VK_RIGHT) {
			rightPressed = false;
		}
		if (code == KeyEvent.VK_DOWN)  {
			downPressed = false;
			
			
 
		
			
			
			
			
	   }
       }
       }
